SAMajwadi Party 2027 - playlist page

Files:
- index.html
- style.css
- script.js

The YouTube playlist is embedded from the playlist URL supplied by the user.

FREE HOSTING:
1. Create a GitHub account.
2. Create a new public repository.
3. Upload these 3 files.
4. Open Settings > Pages.
5. Select Deploy from branch, choose main/root, and save.
6. GitHub will give you a free website address.

NOTE:
The page is a static playlist template. YouTube controls/content remain controlled by YouTube.
